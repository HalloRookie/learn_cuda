version = 'MMult_4x4_9';
MY_MMult = [
error: i 0  j 0 diff 600.000000  got 800.000000  expect 200.000000 
40 diff too big: 6.000000e+02
