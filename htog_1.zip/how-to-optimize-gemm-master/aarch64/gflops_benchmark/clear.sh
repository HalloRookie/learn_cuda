rm -rf main
rm -rf *.o
